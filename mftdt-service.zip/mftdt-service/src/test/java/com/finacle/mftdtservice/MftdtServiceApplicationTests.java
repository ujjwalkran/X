package com.finacle.mftdtservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MftdtServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
