package com.finacle.mftdtservice.service;

import com.finacle.mftdtservice.dto.MftdtResponseDTO;
import com.finacle.mftdtservice.dto.MftdtUpdateRequestDTO;

public interface MftdtService {

    MftdtResponseDTO getByTransactionId(String transactionId);
    MftdtResponseDTO updateTransaction(String transactionId, MftdtUpdateRequestDTO dto);
}
