package com.finacle.mftdtservice.mapper;

import com.finacle.mftdtservice.dto.MftdtResponseDTO;
import com.finacle.mftdtservice.dto.MftdtUpdateRequestDTO;
import com.finacle.mftdtservice.entity.Mftdt;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.BeanWrapper;
import org.springframework.beans.BeanWrapperImpl;
import org.springframework.stereotype.Component;

import java.beans.FeatureDescriptor;
import java.util.Arrays;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Component
public class MftdtMapper {

    // Converts Mftdt entity to MftdtResponseDTO
    public MftdtResponseDTO toDto(Mftdt entity) {
        return MftdtResponseDTO.builder()
                .transactionId(entity.getTransactionId())
                .tranStatus(entity.getTranStatus())
                .srlNum(entity.getSrlNum())
                .tranType(entity.getTranType())
                .tranDate(String.valueOf(entity.getTranDate()))
                .tranAmt(entity.getTranAmt())
                .tranCcy(entity.getTranCcy())
                .omnibusFlg(entity.getOmnibusFlg())
                .bankId(entity.getBankId())
                .entityCreFlg(entity.getEntityCreFlg())
                .delFlg(entity.getDelFlg())
                .inOutInd(entity.getInOutInd())
                .solId(entity.getSolId())
                .invId(entity.getInvId())
                .folioNum(entity.getFolioNum())
                .fundCd(entity.getFundCd())
                .fundCcy(entity.getFundCcy())
                .fundHouseId(entity.getFundHouseId())
                .ruleEffectDate(String.valueOf(entity.getRuleEffectDate()))
                .valueDate(String.valueOf(entity.getValueDate()))
                .ruleTranType(entity.getRuleTranType())
                .tranSubType(entity.getTranSubType())
                .tranMode(entity.getTranMode())
                .additionalAmount1(entity.getAdditionalAmount1())
                .build();
    }

    // Updates Mftdt entity from MftdtUpdateRequestDTO
    public void updateEntityFromDto(MftdtUpdateRequestDTO dto, Mftdt entity) {
        BeanUtils.copyProperties(dto, entity, getNullPropertyNames(dto));
    }

    // Converts Mftdt entity to a pipe-separated string
    public String toPipeSeparatedString(Mftdt entity) {
        return Stream.of(
                entity.getTransactionId(),
                entity.getTranStatus(),
                entity.getSrlNum(),
                entity.getTranType(),
                String.valueOf(entity.getTranDate()),  // Convert Date to String
                String.valueOf(entity.getTranAmt()),   // Convert BigDecimal to String
                entity.getTranCcy(),
                entity.getOmnibusFlg(),
                entity.getBankId(),
                entity.getEntityCreFlg(),
                entity.getDelFlg(),
                entity.getInOutInd(),
                entity.getSolId(),
                entity.getInvId(),
                entity.getFolioNum(),
                entity.getFundCd(),
                entity.getFundCcy(),
                entity.getFundHouseId(),
                String.valueOf(entity.getRuleEffectDate()),  // Convert Date to String
                String.valueOf(entity.getValueDate()),      // Convert Date to String
                entity.getRuleTranType(),
                entity.getTranSubType(),
                entity.getTranMode(),
                String.valueOf(entity.getAdditionalAmount1())  // Convert BigDecimal to String
                // Add more fields as needed
        ).collect(Collectors.joining(" | "));
    }

    // Helper method to get null property names in the DTO
    private String[] getNullPropertyNames(Object source) {
        final BeanWrapper src = new BeanWrapperImpl(source);
        return Arrays.stream(src.getPropertyDescriptors())
                .map(FeatureDescriptor::getName)
                .filter(name -> src.getPropertyValue(name) == null)
                .toArray(String[]::new);
    }
}
