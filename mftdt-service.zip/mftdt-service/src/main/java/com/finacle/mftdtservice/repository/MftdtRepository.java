package com.finacle.mftdtservice.repository;

import com.finacle.mftdtservice.entity.Mftdt;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface MftdtRepository extends JpaRepository<Mftdt, String> {

    Optional<Mftdt> findByTransactionId(String transactionId);
}
