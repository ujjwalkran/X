package com.finacle.mftdtservice.controller;

import com.finacle.mftdtservice.dto.MftdtResponseDTO;
import com.finacle.mftdtservice.dto.MftdtUpdateRequestDTO;
import com.finacle.mftdtservice.service.MftdtService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/transactions")
@RequiredArgsConstructor
public class MftdtController {

    private final MftdtService service;

    @GetMapping("/{id}")
    public ResponseEntity<MftdtResponseDTO> get(@PathVariable String id) {
        return ResponseEntity.ok(service.getByTransactionId(id));
    }

    @PutMapping("/{id}")
    public ResponseEntity<MftdtResponseDTO> update(@PathVariable String id, @RequestBody MftdtUpdateRequestDTO dto) {
        return ResponseEntity.ok(service.updateTransaction(id, dto));
    }
}
