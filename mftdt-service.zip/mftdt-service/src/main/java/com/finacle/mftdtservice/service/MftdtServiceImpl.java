package com.finacle.mftdtservice.service;


import com.finacle.mftdtservice.dto.MftdtResponseDTO;
import com.finacle.mftdtservice.dto.MftdtUpdateRequestDTO;
import com.finacle.mftdtservice.entity.Mftdt;
import com.finacle.mftdtservice.exception.ResourceNotFoundException;
import com.finacle.mftdtservice.mapper.MftdtMapper;
import com.finacle.mftdtservice.repository.MftdtRepository;
import com.finacle.mftdtservice.util.FileWriterUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
@Slf4j
public class MftdtServiceImpl implements MftdtService {

    private final MftdtRepository repository;
    private final MftdtMapper mapper;
    private final FileWriterUtil fileWriter;

    @Override
    public MftdtResponseDTO getByTransactionId(String transactionId) {
        Mftdt entity = repository.findById(transactionId)
                .orElseThrow(() -> new ResourceNotFoundException("Transaction not found"));

        fileWriter.writeToFile("fetched_data.txt", mapper.toPipeSeparatedString(entity));
        return mapper.toDto(entity);
    }

    @Override
    public MftdtResponseDTO updateTransaction(String transactionId, MftdtUpdateRequestDTO dto) {
        Mftdt entity = repository.findById(transactionId)
                .orElseThrow(() -> new ResourceNotFoundException("Transaction not found"));

        mapper.updateEntityFromDto(dto, entity);
        Mftdt saved = repository.save(entity);

        fileWriter.writeToFile("updated_data.txt", mapper.toPipeSeparatedString(saved));
        log.info("Transaction {} updated successfully", transactionId);
        return mapper.toDto(saved);
    }
}
