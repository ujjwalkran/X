package com.finacle.mftdtservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MftdtServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(MftdtServiceApplication.class, args);
    }

}
