package com.finacle.mftdtservice.util;


import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;

@Component
@Slf4j
public class FileWriterUtil {

    public void writeToFile(String filePath, String line) {
        try {
            Files.write(Paths.get(filePath), (line + System.lineSeparator()).getBytes(),
                    StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        } catch (IOException e) {
            log.error("Error writing to file: {}", filePath, e);
        }
    }
}
