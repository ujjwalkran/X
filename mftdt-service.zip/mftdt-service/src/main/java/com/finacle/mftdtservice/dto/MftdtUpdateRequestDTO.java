package com.finacle.mftdtservice.dto;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class MftdtUpdateRequestDTO {

    private String tranStatus;
    private String srlNum;
    private String tranType;
    private String omnibusFlg;
    private String bankId;
    private String entityCreFlg;
    private String delFlg;
    private String inOutInd;
    private String tranDate;
    private String solId;
    private String invId;
    private String folioNum;
    private String fundCd;
    private String fundCcy;
    private String fundHouseId;
    private String ruleEffectDate;
    private String valueDate;
    private String ruleTranType;
    private String tranSubType;
    private String tranMode;
    private Double tranAmt;
    private String tranCcy;
    private Double additionalAmount1;

}
