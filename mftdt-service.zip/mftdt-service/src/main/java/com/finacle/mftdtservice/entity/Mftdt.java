package com.finacle.mftdtservice.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Builder;
import lombok.Data;
import org.antlr.v4.runtime.misc.NotNull;
import org.hibernate.annotations.DynamicUpdate;

import java.util.Date;

@Data
@Builder
@DynamicUpdate // Ensures only updated fields are included in SQL update
@Table(name = "mftdt", schema = "wmsadm") // Define the table name in the database
public class Mftdt {

    @Id
    @NotNull
    @Column(name = "transaction_id", nullable = false, unique = true)
    private String transactionId;

    @NotNull
    @Column(name = "tran_status", nullable = false)
    private String tranStatus;

    @NotNull
    @Column(name = "srl_num", nullable = false)
    private String srlNum;

    @NotNull
    @Column(name = "tran_type", nullable = false)
    private String tranType;

    @NotNull
    @Column(name = "omnibus_flg", nullable = false)
    private String omnibusFlg;

    @NotNull
    @Column(name = "bank_id", nullable = false)
    private String bankId;

    @NotNull
    @Column(name = "entity_cre_flg", nullable = false)
    private String entityCreFlg;

    @NotNull
    @Column(name = "del_flg", nullable = false)
    private String delFlg;

    @NotNull
    @Column(name = "in_out_ind", nullable = false)
    private String inOutInd;

    @NotNull
    @Column(name = "tran_date", nullable = false)
    private Date tranDate;

    @NotNull
    @Column(name = "sol_id", nullable = false)
    private String solId;

    @NotNull
    @Column(name = "inv_id", nullable = false)
    private String invId;

    @NotNull
    @Column(name = "folio_num", nullable = false)
    private String folioNum;

    @NotNull
    @Column(name = "fund_cd", nullable = false)
    private String fundCd;

    @NotNull
    @Column(name = "fund_ccy", nullable = false)
    private String fundCcy;

    @NotNull
    @Column(name = "fund_house_id", nullable = false)
    private String fundHouseId;

    @NotNull
    @Column(name = "rule_effect_date", nullable = false)
    private Date ruleEffectDate;

    @NotNull
    @Column(name = "value_date", nullable = false)
    private Date valueDate;

    @NotNull
    @Column(name = "rule_tran_type", nullable = false)
    private String ruleTranType;

    @NotNull
    @Column(name = "tran_sub_type", nullable = false)
    private String tranSubType;

    @NotNull
    @Column(name = "tran_mode", nullable = false)
    private String tranMode;

    @NotNull
    @Column(name = "tran_amt", nullable = false)
    private Double tranAmt;

    @NotNull
    @Column(name = "tran_ccy", nullable = false)
    private String tranCcy;

    @NotNull
    @Column(name = "additional_amount1", nullable = false)
    private Double additionalAmount1;
}
